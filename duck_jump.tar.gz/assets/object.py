import pygame as pg
import random
import os


class Object:
    vel = 400  # Horizontal speed
    x_min = 0
    y_min = 0
    gravity = 1500  # Gravity acceleration
    jump_speed = -800  # Jump impulse
    vertical_vel = 0
    on_ground = False

    def __init__(self, surface, color="yellow", size=5, sprite_size=120):
        self.surface = surface
        self.color = color
        self.size = size
        self.sprite_size = sprite_size
        self.x_max = self.surface.get_width()
        self.y_max = self.surface.get_height()
        self.pos = self.random_position()
        self.facing_right = True
        # For quack text display
        self.quack_text = None
        self.quack_timer = 0
        # Load player image once (duck.png) from assets/sprites
        img_path = os.path.join("assets", "sprites", "duck.png")
        try:
            self.player_img = pg.image.load(img_path).convert_alpha()
            # Scale the image down to the configured sprite size
            self.player_img = pg.transform.smoothscale(
                self.player_img, (self.sprite_size, self.sprite_size)
            )
        except Exception:
            # Fallback: create a simple surface if image missing
            self.player_img = pg.Surface(
                (self.sprite_size, self.sprite_size), pg.SRCALPHA
            )
            pg.draw.circle(
                self.player_img,
                pg.Color(self.color),
                (self.sprite_size // 2, self.sprite_size // 2),
                self.sprite_size // 2,
            )

        # Load quack image (duck_quack.png) from assets/sprites
        quack_img_path = os.path.join("assets", "sprites", "duck_quack.png")
        try:
            self.quack_img = pg.image.load(quack_img_path).convert_alpha()
            self.quack_img = pg.transform.smoothscale(
                self.quack_img, (self.sprite_size, self.sprite_size)
            )
        except Exception:
            # If quack image doesn't exist, use the regular image
            self.quack_img = self.player_img

    def draw(self, camera_y=0):
        # Use quack image if actively quacking, otherwise use regular image
        img = self.quack_img if (self.quack_timer > 0) else self.player_img

        # Flip image if facing right (assuming sprite naturally faces left)
        if self.facing_right:
            img = pg.transform.flip(img, True, False)

        offset = pg.Vector2(img.get_width() / 2, img.get_height() / 2)
        dest = self.pos - offset
        self.surface.blit(img, (dest.x, dest.y - camera_y))

        # Draw quack text if active
        if self.quack_text and self.quack_timer > 0:
            text_size = getattr(self, "quack_text_size", 36)
            text_color = getattr(self, "quack_color", (0, 0, 0))
            font = pg.font.Font(None, text_size)
            text_surf = font.render(self.quack_text, True, text_color)
            text_pos = (
                self.pos.x - text_surf.get_width() / 2,
                self.pos.y - self.sprite_size / 2 - 10 - camera_y,
            )
            self.surface.blit(text_surf, text_pos)

    def move(self, x, y, dt):
        if x > 0:
            self.facing_right = True
        elif x < 0:
            self.facing_right = False

        # `dt` comes from clock.tick() in milliseconds — convert to seconds
        seconds = dt / 1000.0
        self.pos.x += x * self.vel * seconds
        self.pos.y += y * self.vel * seconds
        self.adjust_pos()

    def jump(self, multiplier=1.0):
        if self.on_ground:
            self.vertical_vel = self.jump_speed * multiplier
            self.on_ground = False

    def applyGravity(self, dt, platforms=[]):
        seconds = dt / 1000.0
        self.vertical_vel += self.gravity * seconds
        self.pos.y += self.vertical_vel * seconds
        self.adjust_pos(platforms)

    def random_position(self):
        return pg.Vector2(self.random_x(), self.random_y())

    def random_left(self):
        return pg.Vector2(self.random_x("left"), self.random_y())

    def random_right(self):
        return pg.Vector2(self.random_x("right"), self.random_y())

    def random_x(self):
        return random.uniform(
            0 + (self.sprite_size / 2),
            self.surface.get_width() - (self.sprite_size / 2),
        )

    def random_y(self):
        return random.uniform(
            0 + (self.sprite_size / 2),
            self.surface.get_height() - (self.sprite_size / 2),
        )

    def get_rect(self):
        half_sprite = self.sprite_size / 2
        return pg.Rect(
            self.pos.x - half_sprite,
            self.pos.y - half_sprite,
            self.sprite_size,
            self.sprite_size,
        )

    def adjust_pos(self, platforms=[]):
        half_sprite = self.sprite_size / 2

        # Screen boundaries - update max values from surface
        self.x_max = self.surface.get_width()
        self.y_max = self.surface.get_height()

        if self.pos.x < self.x_min + half_sprite:
            self.pos.x = self.x_min + half_sprite
        if self.pos.x > self.x_max - half_sprite:
            self.pos.x = self.x_max - half_sprite

        self.on_ground = False

        # Platform collisions
        player_rect = self.get_rect()
        for p in platforms:
            if getattr(p, "is_broken", False):
                continue

            if player_rect.colliderect(p.rect):
                # Only land on top if falling
                if self.vertical_vel > 0:
                    # Check if we were above the platform in the previous frame
                    # Simple version: if bottom of player is near top of platform
                    if player_rect.bottom <= p.rect.top + self.vertical_vel * 0.1 + 10:
                        self.pos.y = p.rect.top - half_sprite
                        self.vertical_vel = 0
                        self.on_ground = True
                        if hasattr(p, "on_stand"):
                            p.on_stand()


def objectFactory(x, y):
    return Object(pg.Vector2(x, y))


class Platform:
    def __init__(self, x, y, width, height):
        self.rect = pg.Rect(x, y, width, height)
        self.color = (255, 255, 255)  # White color

    def update(self, dt):
        pass

    def draw(self, surface, camera_y=0):
        draw_rect = self.rect.copy()
        draw_rect.y -= camera_y
        pg.draw.rect(surface, self.color, draw_rect)


class CollapsingPlatform(Platform):
    def __init__(self, x, y, width, height):
        super().__init__(x, y, width, height)
        self.color = (200, 200, 255)  # Light blue/grey to be visually distinct
        self.collapse_timer = 0
        self.respawn_timer = 0
        self.is_collapsing = False
        self.is_broken = False
        self.is_cracked = False  # For quack identification
        self.show_cracks = False

    def on_stand(self):
        if not self.is_broken:
            self.is_collapsing = True

    def update(self, dt):
        if self.is_broken:
            self.respawn_timer += dt
            if self.respawn_timer >= 5000:  # Respawn after 5 seconds
                self.is_broken = False
                self.is_collapsing = False
                self.collapse_timer = 0
                self.respawn_timer = 0
                self.show_cracks = False
            return

        if self.is_collapsing and not self.is_broken:
            self.collapse_timer += dt
            if self.collapse_timer >= 2000:
                self.is_broken = True
            elif self.collapse_timer >= 1000:
                self.show_cracks = True

    def draw(self, surface, camera_y=0):
        if self.is_broken:
            return

        draw_rect = self.rect.copy()
        draw_rect.y -= camera_y

        # Draw the platform base
        pg.draw.rect(surface, self.color, draw_rect)

        # Draw cracks if breaking or identified by quack
        if self.show_cracks or self.is_cracked:
            crack_color = (100, 100, 100)
            # Simple crack lines
            pg.draw.line(
                surface,
                crack_color,
                (draw_rect.left + 5, draw_rect.top + 5),
                (draw_rect.left + 20, draw_rect.top + 15),
                2,
            )
            pg.draw.line(
                surface,
                crack_color,
                (draw_rect.right - 5, draw_rect.top + 5),
                (draw_rect.right - 20, draw_rect.top + 15),
                2,
            )
            if self.show_cracks:
                # More cracks if it's actually breaking
                pg.draw.line(
                    surface,
                    crack_color,
                    (draw_rect.centerx - 10, draw_rect.top + 2),
                    (draw_rect.centerx + 10, draw_rect.bottom - 2),
                    2,
                )
